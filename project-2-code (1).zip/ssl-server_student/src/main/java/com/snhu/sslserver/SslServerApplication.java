/*
 * Class: CS-305-T4501 Software Security
 * Instructor: Dr. Vivian Lyon
 * Assignment: Project Two
 * Student: Andrej Oljaca
 * Date: 13 APR 2022
 */

package com.snhu.sslserver;

import java.security.MessageDigest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}
	

}

@RestController
class ServerController{
    @RequestMapping("/hash")
    public static String main(String args[]) throws Exception {
        // Create the data variable with my name
        String data = "Andrej Oljaca";
        // Create the instance of MessageDigest
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        // Create the hexString using the instance of MessageDigest
        md.update(data.getBytes());
        byte[] digest = md.digest(); 
        StringBuffer hexString = new StringBuffer();
        for (int i = 0;i<digest.length;i++) {
           hexString.append(Integer.toHexString(0xFF & digest[i]));
        }
        // Return the information and hex string
        return "<p>data:" + data + "\n" + "Name of Cipher Algorithm Used: SHA-256" + "Checksum value" + hexString;
    }
}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";